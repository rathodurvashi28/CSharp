﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace series
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number:");
            int num = Convert.ToInt32(Console.ReadLine());
            //for loop
            int i = 1, old = 0, New = 0;
            for (i = 1; i <= num; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i + "\t");
                    New = i;
                    old = i - 1;
                }
                else
                {
                    int temp = old * New;
                    if (temp > num)
                    {
                        break;
                    }
                    Console.Write(temp + "\t");
                    old = New;
                    New = temp;
                }
            }
            Console.WriteLine(" ");
            //------------do while
            int j = 1;
            do
            {
                if (j <= 3)
                {
                    Console.Write(j + "\t");
                    New = j;
                    old = j - 1;

                }
                else
                {
                    int temp = old * New;
                    if (temp > num)
                    {
                        break;
                    }
                    Console.Write(temp + "\t");
                    old = New;
                    New = temp;
                }
                j++;
            } while (j <= num);
            Console.WriteLine(" ");
            //------while loop
            int k = 1;
            while (k <= num)
            {
                if (k <= 3)
                {
                    Console.Write(k + "\t");
                    New = k;
                    old = k - 1;
                }
                else
                {
                    int temp = old * New;
                    if (temp > num)
                    {
                        break;
                    }
                    Console.Write(temp + "\t");
                    old = New;
                    New = temp;

                }
                k++;
            }
            Console.WriteLine(" ");
            Console.Read();
        }
    }
}
