﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switchcase
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ENTER 1 FOR GRAY BG:");
            Console.WriteLine("ENTER 2 FOR MAGENTA BG:");
            Console.WriteLine("ENTER 3 FOR GREEN BG:");
            int num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.Clear();
                    break;
                case 2:
                    Console.BackgroundColor = ConsoleColor.Magenta;
                    Console.Clear();
                    break;
                case 3:
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;
                default:
                    Console.Write("enter 1 to 3 no!");
                    break;
            }
        }
    }
}
