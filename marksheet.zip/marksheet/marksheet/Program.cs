﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marksheet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ENTER SUBJECT OF THE MARK1:");
            int m1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ENTER SUBJECT OF THE MARK2:");
            int m2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ENTER SUBJECT OF THE MARK3:");
            int m3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ENTER SUBJECT OF THE MARK4:");
            int m4 = Convert.ToInt32(Console.ReadLine());

            int total = m1 + m2 + m3 + m4;
            string result, gread;
            float per = 0;

            if ((m1 > 0 && m2 > 0 && m3 > 0 && m4 > 0) && (m1 <= 100 && m2 <= 100 && m3 <= 100 && m4 <= 100))
            {
                if (m1 >= 40 && m2 >= 40 && m3 >= 40 && m4 >= 40)
                {
                    result = "PASS";
                    per = total / 4;
                    if (per >= 80)
                    {
                        gread = "A";
                    }
                    else if (per >= 70)
                    {
                        gread = "B";
                    }
                    else if (per >= 60)
                    {
                        gread = "C";
                    }
                    else if (per >= 50)
                    {
                        gread = "D";
                    }
                    else
                    {
                        gread = "E";
                    }
                }
                else
                {
                    result = "FAIL";
                    per = 0;
                    gread = "F";
                }
                Console.WriteLine("TOTAL = " + total);
                Console.WriteLine("PER = " + per);
                Console.WriteLine("RESULT = " + result);
                Console.WriteLine("GREAD = " + gread);
            }
            else
            {
                Console.WriteLine("ENTER MARKS OF BETWEEN 0 total 100");
            }
            Console.ReadLine();
        }
    }
}
